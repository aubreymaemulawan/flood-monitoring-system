# Flood Monitoring App

1. Create DB in XXAMP, rename to id19886967_flsys
2. Connect To Database - php artisan migrate
3. Add User - php artisan db:seed
4. Run code - php artisan serve
5. Login Page - http://localhost:8000/login
   a. Username - admin
   b. Password - admin123
6. Main Website - http://localhost:8000
