<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('login_content'); ?>
    <main class="bg-main">
        <div class="container">
            <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-center py-4"> 
                                        <a href="#" class="logo d-flex align-items-center w-auto"> 
                                            <img src="assets/img/logo1.png" alt=""> 
                                            <span class="d-lg-block">FLSys</span> 
                                        </a>
                                    </div>
                                    <h5 class="card-title2 card-title text-center pb-0 fs-4">Welcome Back!</h5>
                                    <p class="text-center small">Enter your username & password to login.</p>
                                    <br>
                                    <!-- Login Form -->
                                    <!-- <form class="row g-3 needs-validation"> -->
                                    <form id="formAuthentication" class="row g-3 " action="<?php echo e(route('login')); ?>" method="POST" novalidate>
                                    <?php echo csrf_field(); ?>
                                        <!-- Username Input -->
                                        <div class="col-12">
                                            <label for="email" class="form-label">Email or Username</label>
                                            <input 
                                                type="text" 
                                                name="email" 
                                                class="form-control form-control-user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="email" 
                                                value="<?php echo e(old('email')); ?>" 
                                                autofocusaria-describedby="emailHelp"
                                                required autocomplete="email" 
                                                autofocus>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Password Input -->
                                        <div class="col-12">
                                            <label for="password" class="form-label">Password</label> 
                                            <input 
                                                type="password" 
                                                name="password" 
                                                class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="password" 
                                                required autocomplete="current-password"
                                                aria-describedby="password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Remember Me -->
                                        <div class="col-12">
                                            <div class="form-check"> 
                                                <input 
                                                    class="form-check-input" 
                                                    type="checkbox" 
                                                    name="remember" 
                                                    id="rememberMe"
                                                    <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="rememberMe"><?php echo e(__('Remember Me')); ?></label>
                                            </div>
                                        </div>

                                        <!-- Sign-in / Submit Button -->
                                        <div class="col-12"> 
                                            <button class="btn btn-primary w-100" type="submit"><?php echo e(__('Login')); ?></button>
                                        </div>

                                        <!-- Forgot Password -->
                                        <div class="col-12">
                                            <p class="small mb-0">Forgot Password?
                                                <a href="#">Click here</a>
                                            </p>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aubrey Mae Mulawan\Desktop\System\flood_monitoring\resources\views/auth/login.blade.php ENDPATH**/ ?>