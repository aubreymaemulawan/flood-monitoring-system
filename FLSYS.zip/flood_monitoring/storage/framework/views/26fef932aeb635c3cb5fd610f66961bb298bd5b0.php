<!-- Footer -->
    <footer id="footer" class="footer">
        <div class="copyright"> &copy; Copyright <strong><span>FMSys</span></strong>. All Rights Reserved</div>
    </footer><?php /**PATH C:\Users\Aubrey Mae Mulawan\Desktop\System\flood_monitoring\resources\views/admin/footer.blade.php ENDPATH**/ ?>