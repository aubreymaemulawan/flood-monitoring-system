<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>


        <!-- Page Title -->
        <title><?php echo $__env->yieldContent('title'); ?>  |  FLSys</title>
        <meta name="robots" content="noindex, nofollow">
        <meta content="" name="description">
        <meta content="" name="keywords">

        <!-- Icon -->
        <link href="<?php echo e(asset('assets/img/favicon-32x32.png')); ?>" rel="icon">
        <link href="<?php echo e(asset('assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Fonts -->
        <link href="https://fonts.gstatic.com" rel="preconnect">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
        
        <!-- Vendors CSS -->
        <link href="<?php echo e(asset('assets/css/datatables.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/bootstrap-icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/boxicons.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/quill.snow.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/quill.bubble.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/remixicon.css')); ?>" rel="stylesheet">
        <link href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css" rel="stylesheet">


        
        
        

        <!-- Main CSS -->
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    </head>

   <body>
    <?php if(auth()->guard()->guest()): ?>
        <!-- Login Route -->
        <?php if(Route::has('login')): ?>
            <?php echo $__env->yieldContent('login_content'); ?>
        <?php endif; ?>
        <?php else: ?>
            <!-- Admin User -->
            <?php if( Auth::user()->user_type == 1): ?>
                <?php echo $__env->yieldContent('modal'); ?>
                <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('admin_content'); ?>
                <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
    <?php endif; ?>
      
      <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>  
        <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script> 
        <script src="<?php echo e(asset('assets/js/jquery-3.6.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.table2excel.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/apexcharts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/echarts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/quill.min.js')); ?>"></script>        
        <script src="<?php echo e(asset('assets/js/tinymce.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootbox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/validate.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script> 
        <script src="<?php echo e(asset('assets/js/core.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/datatables.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" integrity="sha512-BNaRQnYJYiPSqHHDb58B0yaPfCu+Wgds8Gp/gU33kqBtgNS4tSPHuGibyoeqMV/TJlSKda6FXzoEyYGjTe+vXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script type="text/javascript" src="https://momentjs.com/downloads/moment-with-locales.min.js"></script>

        

        

        

        <?php echo $__env->yieldContent('scripts'); ?>    
   </body>
</html><?php /**PATH C:\Users\Aubrey Mae Mulawan\Desktop\System\flood_monitoring\resources\views/layouts/app.blade.php ENDPATH**/ ?>