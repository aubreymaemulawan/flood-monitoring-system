<?php 
    $cnt = count($water_level);
?>
<?php $__currentLoopData = $water_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$wl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($wl->device->status == 1): ?>
    <tr>
        <td><?php echo e($cnt--); ?></td>
        <td><?php echo e($wl->device->location); ?></td>
        <td><?php echo e($wl->height); ?> cm</td>
        <!-- Status column -->
        <?php if($wl->color == 'red'): ?>
        <td><span class="badge rounded-pill bg-danger">Extreme</span></td>
        <?php elseif($wl->color == 'orange'): ?>
        <td><span style="background-color:orange;color:white" class="badge rounded-pill">Severe</span></td>
        <?php elseif($wl->color == 'green'): ?>
        <td><span class="badge rounded-pill bg-success">Above Normal</span></td>
        <?php endif; ?>
        <td>
            <?php
                $date = new DateTime($wl->created_at);
                $result = $date->format('F j, Y, g:i a');
            ?>
            <?php if($wl->created_at != null): ?>
                <?php echo e($result); ?>

            <?php else: ?>
                N/A
            <?php endif; ?>
        </td>
    </tr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Aubrey Mae Mulawan\Desktop\System\flood_monitoring\resources\views/main_table.blade.php ENDPATH**/ ?>